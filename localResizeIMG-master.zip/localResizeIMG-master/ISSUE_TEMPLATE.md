很抱歉，这个项目已不再维护了，可能很长一段时间都不会更新了。
如果真的需要，请使用之前请一定留意 [Issues](https://github.com/think2011/localResizeIMG/issues?q=is%3Aissue+is%3Aopen+label%3Abug) 里已知的问题
